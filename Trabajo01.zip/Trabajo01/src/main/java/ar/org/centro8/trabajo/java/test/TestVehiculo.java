package ar.org.centro8.trabajo.java.test;

import ar.org.centro8.trabajo.java.entities.AutoClasico;
import ar.org.centro8.trabajo.java.entities.AutoNuevo;
import ar.org.centro8.trabajo.java.entities.Bondi;

public class TestVehiculo {
    public static void main(String[] args) {
        System.out.println("-- Auto Clasico --");
        AutoClasico autoClasico1 = new AutoClasico("Renault", "Torino", "Blanco");
        System.out.println(autoClasico1);

        autoClasico1.setRadio("Blauline", 45);
        System.out.println(autoClasico1);

        System.out.println("-- Auto Nuevo --");
        AutoNuevo autoNuevo1 = new AutoNuevo("Toyota", "Corolla", "Violeta", "Pioneer", 50);
        System.out.println(autoNuevo1);

        autoNuevo1.setRadio("Sony", 55);
        System.out.println(autoNuevo1);

        autoNuevo1.setPrecio(26000);
        System.out.println(autoNuevo1);

        System.out.println("-- Bondi --");
        Bondi bondi1 = new Bondi("JAC", "S3", "Azul");
        System.out.println(bondi1);

        bondi1.setRadio("Nakamichi", 50);
        System.out.println(bondi1);

        bondi1.setPrecio(38500);
        System.out.println(bondi1);
    }

}
