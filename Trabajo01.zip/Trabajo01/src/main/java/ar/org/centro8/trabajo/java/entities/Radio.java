package ar.org.centro8.trabajo.java.entities;

import lombok.Getter;

@Getter
public class Radio {
    private String marcaRadio;
    private int potencia;
    
    public Radio(String marcaRadio, int potencia) {
        this.marcaRadio = marcaRadio;
        this.potencia = potencia;
    }

    @Override
    public String toString() {
        return "[marca=" + marcaRadio + ", potencia=" + potencia + " W]";
    }

}
