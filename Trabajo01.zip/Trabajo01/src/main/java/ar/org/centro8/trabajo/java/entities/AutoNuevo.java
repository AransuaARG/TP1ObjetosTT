package ar.org.centro8.trabajo.java.entities;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AutoNuevo extends Vehiculo{
    String marcaRadio;
    int potencia;
    
    public AutoNuevo(String marca, String modelo, String color, String marcaRadio,
            int potencia) {
        super(marca, modelo, color);
        super.radio = new Radio(marcaRadio, potencia);
    }
    
}
