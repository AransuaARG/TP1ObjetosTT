package ar.org.centro8.trabajo.java.entities;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AutoClasico extends Vehiculo{
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

}
