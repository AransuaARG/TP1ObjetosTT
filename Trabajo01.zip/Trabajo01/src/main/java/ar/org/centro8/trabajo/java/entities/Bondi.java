package ar.org.centro8.trabajo.java.entities;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Bondi extends Vehiculo{
    public Bondi(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

}
