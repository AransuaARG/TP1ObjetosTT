package ar.org.centro8.trabajo.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public abstract class Vehiculo {
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    protected Radio radio;
    
    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public Vehiculo(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public void setRadio(String marcaRadio, int potencia) {
        radio = new Radio(marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return "[marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", radio=" + radio + "]";
    }
    
}
